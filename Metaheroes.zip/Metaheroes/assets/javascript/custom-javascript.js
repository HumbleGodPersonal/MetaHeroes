﻿

/* -------------------- AOS Setting -------------------- */

AOS.init({
    duration: 1000,
    once: true,
});

/* -------------------- Navbar Setting -------------------- */

$(window).scroll(function () {
    $(".navbar").toggleClass("scroll", $(this).scrollTop() > 1)
    $("#scroll-top").toggleClass("scroll", $(this).scrollTop() > 1)
});

/* -------------------- Slick Setting -------------------- */

/* Single Slick - Center*/

$('.slick-responsive-auto-center.single').slick({
    lazyLoad: 'ondemand',
    mobileFirst: true,
    variableWidth: true,
    dots: true,
    arrows: true,
    centerMode: true,
    slidesToShow: 1,
    slidesToScroll: 1,
    infinite: true,
    autoplay: true,
    autoplaySpeed: 3500,
});